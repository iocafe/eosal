/**

  @file    eosal_jpeg/eosal_code/osal_jpeg_src.c
  @brief   eosal API for libjpeg.
  @author  Pekka Lehtikoski
  @version 1.0
  @date    5.5.2020

  Copyright 2020 Pekka Lehtikoski. This file is part of the eosal and shall only be used,
  modified, and distributed under the terms of the project licensing. By continuing to use, modify,
  or distribute this file you indicate that you have read the license and understand and accept
  it fully.

  Copyright (C) 1991-1998, Thomas G. Lane. This file is derived from work of the Independent
  JPEG Group's software.

****************************************************************************************************
*/
#include "eosal_jpeg.h"
#include "eosal_code/osal_jpeg_src.h"
// #include "code/jerror.h"

/** Source manager structure for uncompressing JPEGs. This is used to
    uncompress JPEG from data.
 */
typedef struct osaJpegSrcManager
{
    /* Public fields, defined by libjpeg
     */
    struct jpeg_source_mgr pub;

    /* Simple buffer, JPEG data can be alternatively read from here.
     */
    /* os_uchar *src_buf;
    os_memsz src_nbytes;
    os_memsz src_pos; */
}
osaJpegSrcManager;

/** Pointer to osaJpegSrcManager structure type.
 */
typedef osaJpegSrcManager * osaJpegSrcPtr;


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, initialize source.

  The osal_jpeg_init_source function is helper callback, which should
  initialize the data source. This function is
  called by jpeg_read_header before any data is actually read.

  @param  dp JPEG library's internal state structure pointer?
  @return None.

****************************************************************************************************
*/
static void osal_jpeg_init_source(
    j_decompress_ptr dp)
{
}


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, read more (called only on
         error).

  The osal_jpeg_fill_input_buffer function is helper callback, which by default
  should fill the input buffer, called whenever JPEG decompression runs
  out of data.

  @param  dp JPEG library's internal state structure pointer?
  @return Always TRUE.

****************************************************************************************************
*/
static int osal_jpeg_fill_input_buffer(
    j_decompress_ptr dp)
{
    ERREXIT(dp, JERR_INPUT_EMPTY);
    return TRUE;
}


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, skip some input data.

  The osal_jpeg_skip_input_data function is helper callback, which skips input
  data. This function is used to skip over a potentially large amount
  of uninteresting data (such as an APPn marker).

  @param  dp JPEG library's internal state structure pointer?
  @return None.

****************************************************************************************************
*/
static void osal_jpeg_skip_input_data(
    j_decompress_ptr dp,
    long num_bytes)
{
    osaJpegSrcPtr src = (osaJpegSrcPtr) dp->src;

    if (num_bytes > 0)
    {
        src->pub.next_input_byte += (size_t) num_bytes;
        src->pub.bytes_in_buffer -= (size_t) num_bytes;
    }
}


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, skip some input data.

  The osal_jpeg_term_source function is helper callback, which should terminate
  the data source.

  NB: *not* called by jpeg_abort or jpeg_destroy; surrounding
  application must deal with any cleanup that should happen even
  for error exit.

  @param  dp JPEG library's internal state structure pointer?
  @return None.

****************************************************************************************************
*/
static void osal_jpeg_term_source(
    j_decompress_ptr dp)
{
}


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, output error message.

  The osal_jpeg_src_output_message function is helper callback, which
  outputs JPEG uncompression error into program error list.

  @param  cinfo JPEG library's internal state structure pointer?
  @return None.

****************************************************************************************************
*/
#if 0
static void osal_jpeg_src_output_message(
    j_common_ptr cinfo)
{
    char buffer[JMSG_LENGTH_MAX];

    /* Create the message
     */
    (*cinfo->err->format_message) (cinfo, buffer);

    osal_debug_error(buffer);
}
#endif


/**
****************************************************************************************************

  @brief Prepare for JPEG uncompression.

  The osal_jpeg_setup_source function prepares j_decompress structure
  cprm for JPEG input.

  We are here using byte buffers (osal_jpeg_bytebufClass), which are buffers
  in memory, and do not need to be opened or closed. If files would
  be used, the caller must have already opened the stream, and
  is responsible for closing it after finishing compression.

  @param  cprm Pointer JPEG library decompression structure to set up.
  @param  bbuf Pointer to buffer from which the JPEG data
          will be read from.

  @return None.

****************************************************************************************************
*/
void osal_jpeg_setup_source(
    void *cprm,
    osalStream src_stream,
    os_uchar *src_buf,
    os_memsz src_nbytes)
{
    osaJpegSrcPtr src;
    j_decompress_ptr dp = cprm;
    // struct jpeg_error_mgr * err;

    /* First time for this JPEG object?
     */
    if (dp->src == NULL)
    {
        dp->src = (struct jpeg_source_mgr *)
          (*dp->mem->alloc_small) ((j_common_ptr) dp, JPOOL_PERMANENT,
                  sizeof(osaJpegSrcManager));
    }

    src = (osaJpegSrcPtr) dp->src;
    src->pub.init_source = osal_jpeg_init_source;
    src->pub.fill_input_buffer = osal_jpeg_fill_input_buffer;
    src->pub.skip_input_data = osal_jpeg_skip_input_data;
    src->pub.resync_to_restart = jpeg_resync_to_restart; /* use default method */
    src->pub.term_source = osal_jpeg_term_source;
    src->pub.bytes_in_buffer = src_nbytes;
    src->pub.next_input_byte = (os_char*)src_buf;

    /* src->stream = stream;
    src->src_buf = src_buf;
    src->src_nbytes = src_nbytes;
    src->src_pos = 0; */

    /* err = dp->err;
    if (err != NULL)
    {
        err->output_message = osal_jpeg_src_output_message;
    } */
}

