/**

  @file    eosal_jpeg/eosal_code/osal_compress_jpeg.c
  @brief   eosal API for libjpeg.
  @author  Pekka Lehtikoski
  @version 1.0
  @date    5.5.2020

  Copyright 2020 Pekka Lehtikoski. This file is part of the eosal and shall only be used,
  modified, and distributed under the terms of the project licensing. By continuing to use, modify,
  or distribute this file you indicate that you have read the license and understand and accept
  it fully.

  Copyright (C) 1991-1998, Thomas G. Lane. This file is derived from work of the Independent
  JPEG Group's software.

****************************************************************************************************
*/
#include "eosal_jpeg.h"
#include "code/jerror.h"
#include "eosal_code/osal_jpeg_dst.h"
#include "eosal_code/osal_jpeg_src.h"

#include <setjmp.h>

/** Libjpeg's error handler structure, extended by setjump buffer. C standard library setjmp/longjmp
    mechanism is used to return control to the calling function if JPEG compression or decompression
    fails. This sturcture started with default libjpeg fields "buf" followed by application specific
    jump_buffer to exit the compression.
 */
typedef struct osalJpegErrorManager
{
    struct jpeg_error_mgr pub;
    jmp_buf jump_buffer;
}
osalJpegErrorManager;

/* Forward referred static function.
 */
static void osal_jpeg_disaster_exit(
    j_common_ptr ptr);


/**
****************************************************************************************************

  @brief Convert a bitmap in memory to JPEG.
  @anchor os_compress_JPEG

  The os_compress_JPEG() function stores resulting JPEG into stream or to buffer allocated by
  application.

  @param   src Source bitmap data.
  @param   w Source bitmap width in pixels.
  @param   h Source bitmap height in pixels.
  @param   format Source bitmap format, one of: OSAL_GRAYSCALE8, OSAL_GRAYSCALE16, OSAL_RGB24,
           or OSAL_RGBA32.
  @param   quality Compression quality, 0 - 100.
  @param   dst_stream Stream where to store the resulting JPEG. OS_NULL if storing JPEG to
           application allocated buffer.
  @param   dst_buf Pointer to buffer where to store resulting JPEG. OS_NULL if storing JPEG to
           stream.
  @param   dst_buf_sz Destination buffer size, if using allocated buffer. Ignored if
           compressing to a stream.
  @param   dst_nbytes Pointer where to store resulting JPEG size upon successfull compression.
  @param   flags Bit fields, set OSAL_JPEG_DEFAULT (0) for default operation. Set
           OSAL_JPEG_SELECT_ALPHA_CHANNEL bit to save alpha channel of RGGB132 bitmap.

  @return  OSAL_SUCCESS if all is good. Other return values indicate an error.

****************************************************************************************************
*/
osalStatus os_compress_JPEG(
    os_uchar *src,
    os_int w,
    os_int h,
    osalBitmapFormat format,
    os_int quality,
    osalStream dst_stream,
    os_uchar *dst_buf,
    os_memsz dst_buf_sz,
    os_memsz *dst_nbytes,
    os_int flags)
{
    struct jpeg_compress_struct prm;            /* Compression parameters. */
    struct osalJpegErrorManager err_manager;    /* Own error manager */
    JSAMPROW row_pointer[1];                    /* Pointer source scanline. */
    os_uchar *s, *d, *b, *scanline;
    os_int count;
    osalStatus status = OSAL_SUCCESS;

    *dst_nbytes = 0;

    /* Check arguments.
     */
    if (src == OS_NULL || w <= 0 || h <= 0) {
        osal_debug_error("compress JPEG: illegal argument.");
        return OSAL_STATUS_FAILED;
    }

    /* Set libjpeg error handling and override error_exit so that compression errors will
       cause osal_jpeg_disaster_exit to call longjump to return here.
     */
    os_memclear(&prm, sizeof(prm));
    prm.err = jpeg_std_error(&err_manager.pub);
    err_manager.pub.error_exit = osal_jpeg_disaster_exit;
    if (setjmp(err_manager.jump_buffer))
    {
        jpeg_destroy_compress(&prm);
        osal_debug_error("compress JPEG: compression failed.");
        return OSAL_STATUS_FAILED;
    }

    /* Set up the JPEG compression state structure and destination .
     */
    jpeg_create_compress(&prm);
    osal_jpeg_setup_destination(&prm, dst_stream, dst_buf, dst_buf_sz);

    /* Store image size.
     */
    prm.image_width = w;
    prm.image_height = h;

    /* Set up number of input components and the color space. Image is encoded as 8 or 16
       bit per pixel grayscale image or 24 bit color image.
     */
    switch (format)
    {
        /* 8 or 16 bit per pixel grayscale image, one color component per pixel.
         */
        case OSAL_GRAYSCALE8:
        case OSAL_GRAYSCALE16:
            prm.input_components = 1;
            prm.in_color_space = JCS_GRAYSCALE;
            break;

        /* 24 or 32 bit/pixel collor image, three color components per pixel.
         */
        case OSAL_RGBA32:
            if (flags & OSAL_JPEG_SELECT_ALPHA_CHANNEL) {
                prm.input_components = 1;
                prm.in_color_space = JCS_GRAYSCALE;
                break;
            }
            /* continues... */

        case OSAL_RGB24:
            prm.input_components = 3;
            prm.in_color_space = JCS_RGB;
            break;

        default:
            osal_debug_error("compress JPEG: unsupported image format.");
            jpeg_destroy_compress(&prm);
            return OSAL_STATUS_FAILED;
    }

    /* Initialize prm with default compression parameters and set
       compression quality.
     */
    jpeg_set_defaults(&prm);
    jpeg_set_quality(&prm, quality, TRUE);

    /* Start compressor. TRUE ensures that we will write
       a complete interchange-JPEG format.
     */
     jpeg_start_compress(&prm, TRUE);

    /* Create the JPEG. We use the library's state variable
       prm.next_scanline as the loop counter, so that we
       don't have to keep track ourselves. To keep things
       simple, we pass one scanline per call.
     */
    switch (format)
    {
        /* Formats that can be writted directly (8 bit grayscale)
         */
        default:
        case OSAL_GRAYSCALE8:
            while (prm.next_scanline < prm.image_height)
            {
                row_pointer[0] = (os_char*)(src + prm.next_scanline * w);
                jpeg_write_scanlines(&prm, row_pointer, 1);
            }
            break;

        /* 16 bit/pixel grayscale image
         */
        case OSAL_GRAYSCALE16:
            /* Allocate buffer to convert a scan line to 8 bit grayscale.
             */
            b = (os_uchar*)os_malloc(w, OS_NULL);
            if (b == OS_NULL)
            {
                status = OSAL_STATUS_MEMORY_ALLOCATION_FAILED;
                goto getout;
            }
#if OSAL_SMALL_ENDIAN
            scanline = src + 1;
#else
            scanline = src;
#endif

            /* Go through image, scan line at a time.
             */
            while (prm.next_scanline < prm.image_height)
            {
                /* Convert a scan line from 16 bit grayscale to 8 bit grayscale.
                 */
                count = w;
                d = b;
                s = scanline;

                /* Use only more significant bytes.
                 */
                while (count--)
                {
                    *(d++) = *s;
                    s += 2;
                }

                /* Compress scan line.
                 */
                row_pointer[0] = (os_char*)b;
                jpeg_write_scanlines(&prm, row_pointer, 1);

                /* Advance to next scan line.
                 */
                scanline += 2 * w;
            }

            /* Release scan line buffer.
             */
            os_free(b, w);
            break;

        /* 24 bit/pixel color image
         */
        case OSAL_RGB24:
            /* Allocate buffer to convert a scan line to 24 bit RGB.
             */
            b = (os_uchar*)os_malloc(3*w, OS_NULL);
            if (b == OS_NULL)
            {
                status = OSAL_STATUS_MEMORY_ALLOCATION_FAILED;
                goto getout;
            }
            scanline = src;

            /* Go through image, scan line at a time.
             */
            while (prm.next_scanline < prm.image_height)
            {
                /* Convert a scan line from 16 bit RGBA to 24 bit RGB.
                 */
                count = w;
                d = b;
                s = scanline;

                /* Copy RGB info (either RGB or BGR order).
                 */
                while (count--)
                {
#if OE_BGR_COLORS
                    d[2] = *(s++); d[1] = *(s++); d[0] = *(s++); d += 3;
#else
                    *(d++) = *(s++); *(d++) = *(s++); *(d++) = *(s++);
#endif
                }

                /* Compress a scan line and move to next one.
                 */
                row_pointer[0] = (os_char*)b;
                jpeg_write_scanlines(&prm, row_pointer, 1);
                scanline += 3 * w;
            }

            /* Release scan line buffer.
             */
            os_free(b, 3 * w);
            break;

        /* 32 bit/pixel color image with alpha channel.
         */
        case OSAL_RGBA32:
            /* Allocate buffer to convert a scan line to 24 bit RGB.
             */
            b = (os_uchar*)os_malloc(3*w, OS_NULL);
            if (b == OS_NULL)
            {
                status = OSAL_STATUS_MEMORY_ALLOCATION_FAILED;
                goto getout;
            }
            scanline = src;

            /* Go through image, scan line at a time.
             */
            while (prm.next_scanline < prm.image_height)
            {
                /* Convert a scan line from 16 bit RGBA to 24 bit RGB.
                 */
                count = w;
                d = b;
                s = scanline;

                /* Copy RGB info  (either RGB or BGR order), skip alpha channnel.
                 */
                while (count--)
                {
#if OE_BGR_COLORS
                    d[2] = *(s++); d[1] = *(s++); d[0] = *(s++); d += 3;
#else
                    *(d++) = *(s++); *(d++) = *(s++); *(d++) = *(s++);
#endif
                    s++;
                }

                /* Compress scan line and move to next one.
                 */
                row_pointer[0] = (os_char*)b;
                jpeg_write_scanlines(&prm, row_pointer, 1);
                scanline += 4 * w;
            }

            /* Release scan line buffer.
             */
            os_free(b, 3 * w);
            break;

    }

    /* Finished.
     */
getout:
    jpeg_finish_compress(&prm);
    jpeg_destroy_compress(&prm);
    return status;
}


/**
****************************************************************************************************

  @brief Uncompress JPEG to bitmap in memory.
  @anchor os_uncompress_JPEG

  The os_uncompress_JPEG() function stores resulting bitmap...

  @param   src_stream Stream from which to read the JPEG. OS_NULL to get the JPEG data from
           buffer.
  @param   src_buf Pointer to source JPEG data, or OS_NULL if reading JPEG from stream.
  @param   src_nbytes Size of JPEG data in bytes.
  @param   w Pinter Source bitmap width in pixels.
  @param   h Source bitmap height in pixels.
  @param   format Source bitmap format, one of: OSAL_GRAYSCALE8, OSAL_GRAYSCALE16, OSAL_RGB24,
           or OSAL_RGBA32.
  @param   quality Compression quality, 0 - 100.
  @param   dst_stream Stream where to store the resulting JPEG. OS_NULL if storing JPEG to
           application allocated buffer.
  @param   dst_buf Pointer to buffer where to store resulting JPEG. OS_NULL if storing JPEG to
           stream.
  @param   dst_buf_sz Destination buffer size, if using allocated buffer. Ignored if
           compressing to a stream.
  @param   dst_nbytes Pointer where to store resulting JPEG size upon successfull compression.
  @param   flags Bit fields, set OSAL_JPEG_DEFAULT (0) for default operation. Set
           OSAL_JPEG_SELECT_ALPHA_CHANNEL bit to save alpha channel of RGGB132 bitmap.

  @return  OSAL_SUCCESS if all is good. Other return values indicate an error.

****************************************************************************************************
*/
osalStatus os_uncompress_JPEG(
    osalStream src_stream,
    os_uchar *src_buf,
    os_memsz src_nbytes,
    os_int *pw,
    os_int *ph,
    osalBitmapFormat *pformat,
    osal_jpeg_malloc_func *alloc_func,
    osalJpegMallocContext *alloc_context,
    os_int flags)
{
    struct jpeg_decompress_struct prm;          /* Decompression parameters */
    struct osalJpegErrorManager err_manager;    /* Own error manager */
    os_uchar *d, *s, *p, *b, *scanline;
    os_memsz sz;
    os_int count, w, h;
    // os_ushort v;
    osalStatus status = OSAL_SUCCESS;
    osalBitmapFormat format;

    /* Check arguments.
     */
    if (src_buf == OS_NULL) {
        osal_debug_error("compress JPEG: illegal argument.");
        return OSAL_STATUS_FAILED;
    }

    /* Set libjpeg error handling and override error_exit so that compression errors will
       cause osal_jpeg_disaster_exit to call longjump to return here.
     */
    os_memclear(&prm, sizeof(prm));
    prm.err = jpeg_std_error(&err_manager.pub);
    err_manager.pub.error_exit = osal_jpeg_disaster_exit;
    if (setjmp(err_manager.jump_buffer))
    {
        jpeg_destroy_decompress(&prm);
        osal_debug_error("compress JPEG: compression failed.");
        return OSAL_STATUS_FAILED;
    }

    /* Initialize the decompresser.
     */
    jpeg_create_decompress(&prm);

    /* Set up the data source (where to get JPEG data), either stream or memory buffer.
     */
    osal_jpeg_setup_source (&prm, src_stream, src_buf, src_nbytes);

    /* Read JPEG parameters with jpeg_read_header()
     */
    jpeg_read_header(&prm, TRUE);

    /* Start decompressor.
     */
    jpeg_start_decompress(&prm);

    w = prm.output_width;
    h = prm.output_height;
    format = prm.num_components == 1 ? OSAL_GRAYSCALE8 : OSAL_RGB24,
    sz = w * h * prm.num_components;

    /* Verify that parameters within JPEG are correct.
     */
    if (prm.output_height <= 0 ||
        prm.output_width  <= 0)
    {
        osal_debug_error("Errornous JPEG data");
        status = OSAL_STATUS_FAILED;
        goto getout;
    }

    if (alloc_func)
    {
        status = alloc_func(alloc_context, sz);
        if (status) goto getout;

        /*      prm.output_width,
             prm.output_height,
             prm.num_components==1?OSAL_GRAYSCALE8:OSAL_RGB24,
             OEARR_SET_ALL|OEARR_FIXEDSIZEX);
        */
    }

    /* Uncompress and place into bitmap.
     */
    switch (format)
    {
        /* 8 bit/pixel grayscale image
         */
        case OSAL_GRAYSCALE8:
            p = src_buf;
            while (prm.output_scanline < prm.output_height)
            {
                jpeg_read_scanlines(&prm, &p, 1);
                p += w;
            }
            break;

        /* 24 bit/pixel RGB image
         */
        case OSAL_RGB24:
            /* Allocate buffer for reading 24 bit RGB data.
             */
            b = (os_uchar*)os_malloc(3 * w, OS_NULL);
            if (b == OS_NULL)
            {
                status = OSAL_STATUS_MEMORY_ALLOCATION_FAILED;
                goto getout;
            }
            scanline = src_buf;

            /* Go through image, scan line at a time.
             */
            while (prm.output_scanline < prm.output_height)
            {
                jpeg_read_scanlines(&prm, &b, 1);

                count = w;
                d = scanline;
                s = b;

                while (count--)
                {
#if OE_BGR_COLORS
                    d[2] = *(s++); d[1] = *(s++); d[0] = *(s++); d += 3;
#else
                    *(d++) = *(s++); *(d++) = *(s++); *(d++) = *(s++);
#endif
                }

                /* Advance to next scan line.
                 */
                scanline += 3 * w;
            }

            os_free(b, 3 * w);
            break;

        /* 32 bit/pixel RGB image with alpha channel
         */
        case OSAL_RGBA32:
            /* Allocate buffer for reading 24 bit RGB data.
             */
            b = (os_uchar*)os_malloc(3 * w, OS_NULL);
            if (b == OS_NULL)
            {
                status = OSAL_STATUS_MEMORY_ALLOCATION_FAILED;
                goto getout;
            }
            scanline = src_buf;

            /* Go through image, scan line at a time.
             */
            while (prm.output_scanline < prm.output_height)
            {
                jpeg_read_scanlines(&prm, &b, 1);

                count = w;
                d = scanline;
                s = b;

                while (count--)
                {
#if OE_BGR_COLORS
                    d[2] = *(s++); d[1] = *(s++); d[0] = *(s++); d += 3;
#else
                    *(d++) = *(s++); *(d++) = *(s++); *(d++) = *(s++);
#endif
                    *(d++) = 0xFF;
                }

                /* Next scan line.
                 */
                scanline += 4 * w;
            }

            os_free(b, 3 * w);
            break;

        default:
            osal_debug_error("uncompress JPEG: unsupported image format.");
            break;
    }

    /* Finished.
     */
getout:
    jpeg_finish_decompress(&prm);
    jpeg_destroy_decompress(&prm);
    return status;
}


/**
****************************************************************************************************

  @brief Jump to exit compression/decompression on error.
  @anchor os_compress_JPEG

  This function is called by libjpeg if compression or decompression fails. It calls longjump
  to terminate compression/decompression.

  @param   ptr libjpg common pointer.
  @return  None

****************************************************************************************************
*/
static void osal_jpeg_disaster_exit(
    j_common_ptr ptr)
{
/*     osal_jpeg_error_manager *err_manager;

    err_manager = (osal_jpeg_error_manager*) ptr->err;
    longjmp(err_manager->jump_buffer, 1);
  */
}
