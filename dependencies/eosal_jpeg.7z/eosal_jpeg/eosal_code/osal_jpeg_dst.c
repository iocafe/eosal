/**

  @file    eosal_jpeg/eosal_code/osal_jpeg_dst.c
  @brief   eosal API for libjpeg.
  @author  Pekka Lehtikoski
  @version 1.0
  @date    5.5.2020

  This file contains simple error-reporting and trace-message routines. These routines are
  used by both the compression and decompression code.

  Copyright 2020 Pekka Lehtikoski. This file is part of the eosal and shall only be used,
  modified, and distributed under the terms of the project licensing. By continuing to use, modify,
  or distribute this file you indicate that you have read the license and understand and accept
  it fully.

  Copyright (C) 1991-1998, Thomas G. Lane. This file is derived from work of the Independent
  JPEG Group's software.

****************************************************************************************************
*/
#include "eosal_jpeg.h"
#include "eosal_code/osal_jpeg_dst.h"

/** Destination manager structure for compressing JPEGs.
 */
typedef struct
{
  /* Public fields, defined by libjpeg
   */
  struct jpeg_destination_mgr pub;

  /* Stream output.
   */
  osalStream stream;
}
osaJpegDstManager;

/** Pointer to osaJpegDstManager structure type.
 */
typedef osaJpegDstManager *osaJpegDstPtr;


/**
****************************************************************************************************

  @brief Initialize JPEG library.

  The osal_jpeg_init function is called to initialize underlying JPEG
  library. In practise this function only creates mutex to synchronize
  access to the JPEG library. Is the mutex necessary? I used the mutex
  because I was unsure whether libjpeg code is reentrant.

  @return None.

****************************************************************************************************
*/
void osal_jpeg_init(void)
{
}


/**
****************************************************************************************************

  @brief Shutdown JPEG library.

  The osal_jpeg_shutdown function is called to shut down the underlying
  JPEG library. In practise this function only deletes mutex to
  synchronize access to the JPEG library.

  @return None.

****************************************************************************************************
*/
void osal_jpeg_shutdown(void)
{
}

/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, initialize destination.

  The osal_jpeg_init_destination function initializes destination for writing.
  This function is called by jpeg_start_compress before any data is
  actually written.

  @param  cinfo JPEG library's internal state structure pointer?
  @return None.

****************************************************************************************************
*/
METHODDEF(void) osal_jpeg_init_destination(
    j_compress_ptr cinfo)
{
    static os_memsz minimum_size = 64000;
    os_memsz usedsize, bufsz;
    osaJpegDstPtr dest = (osaJpegDstPtr) cinfo->dest;

    /* Make sure that there is at least minimum_size
       bytes free in buffer.
     */
    usedsize = oebytebuf_getusedsize(dest->bbuf);
    if (oebytebuf_getsize(dest->bbuf) < minimum_size + usedsize)
    {
        oebytebuf_alloc(dest->bbuf,
            minimum_size + usedsize, OEBB_PRESERVE);
    }

    /* Set up variables where the compressor should write
       and how much free space there is left
     */
    bufsz = oebytebuf_getsize(dest->bbuf);
    dest->pub.next_output_byte = oebytebuf_getptr(dest->bbuf) + usedsize;
    dest->pub.free_in_buffer = (osal_jpeg_int32)(bufsz - usedsize);
}


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, flush JPEG output buffer.

  The osal_jpeg_empty_output_buffer function is helper callback, which
  empties the JPEG output buffer --- called whenever buffer fills up.

  In typical applications, this should write the entire output buffer
  (ignoring the current state of next_output_byte & free_in_buffer),
  reset the pointer & count to the start of the buffer, and return TRUE
  indicating that the buffer has been dumped.

  @param  cinfo JPEG library's internal state structure pointer?
  @return Always osal_jpeg_TRUE to indicate success, and that there is no
          need to stop the JPEG output.

****************************************************************************************************
*/
METHODDEF(boolean) osal_jpeg_empty_output_buffer(
    j_compress_ptr cinfo)
{
    osal_jpeg_bigint
        bytesz,
        usedsz;

    osaJpegDstPtr
        dest = (osaJpegDstPtr) cinfo->dest;

    /* Get current buffer information
     */
    usedsz = oebytebuf_getsize(dest->bbuf);

    /* Double the buffer size, while preserving the data.
       And set pointer to where to store next byte
     */
    dest->pub.next_output_byte
        = oebytebuf_alloc(dest->bbuf, 2*usedsz, OEBB_PRESERVE) + usedsz;

    /* Set amount of free space in buffer
     */
    bytesz = oebytebuf_getsize(dest->bbuf);
    dest->pub.free_in_buffer = (osal_jpeg_int32)(bytesz - usedsz);

    return TRUE;
}


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, finalize output buffer.

  The osal_jpeg_term_destination function is helper callback, which terminates
  the destination --- called by jpeg_finish_compress after all data has
  been written. Usually this function would need to flush buffer.

  NB: *not* called by jpeg_abort or jpeg_destroy; surrounding
  application must deal with any cleanup that should happen even
  for error exit.

  @param  cinfo JPEG library's internal state structure pointer?
  @return None.

****************************************************************************************************
*/
METHODDEF(void) osal_jpeg_term_destination(
    j_compress_ptr cinfo)
{
    osaJpegDstPtr
        dest = (osaJpegDstPtr) cinfo->dest;

    os_memsz
        bytes;

    /* Write down how many bytes are used for JPEG data.
     */
    bytes = oebytebuf_getsize(dest->bbuf) - dest->pub.free_in_buffer;
    oebytebuf_setusedsize(dest->bbuf, bytes);
    oebytebuf_alloc(dest->bbuf, bytes, OEBB_PRESERVE);
}


/**
****************************************************************************************************

  @brief Callback function for the JPEG lib, output error message.

  The osal_jpeg_dst_output_message function is helper callback, which
  outputs JPEG compression error into program error list.

  @param  cinfo JPEG library's internal state structure pointer?
  @return None.

****************************************************************************************************
*/
METHODDEF(void) osal_jpeg_dst_output_message(
    j_common_ptr cinfo)
{
    char
        buffer[JMSG_LENGTH_MAX];

    /* Create the message
     */
    (*cinfo->err->format_message) (cinfo, buffer);

    /* Append to program error list.
     */
    osal_jpeg_program_error(buffer);
}


/**
****************************************************************************************************

  @brief Prepare for JPEG compression.

  The osal_jpeg_setup_destination function prepares jpeg_compress structure
  cprm for JPEG output. The output will be written in byte buffer bbuf
  given as argument.

  We are here using byte buffers (osal_jpeg_bytebufClass), which are buffers
  in memory, and do not need to be opened or closed. If files would
  be used, the caller must have already opened the stream, and
  is responsible for closing it after finishing compression.

  @param  cprm jpeg_compress_struct Pointer JPEG library compression
          structure to set up.
  @param  stream  Stream into which the resulting JPEG data will be written to.

  @return None.

****************************************************************************************************
*/
void osal_jpeg_setup_destination(
    void *cprm,
    osalStream dst_stream,
    os_uchar *dst_buf,
    os_memsz dst_buf_sz)
{
    osaJpegDstPtr dest;
    struct jpeg_error_mgr *err;
    j_compress_ptr cinfo;

    cinfo = (j_compress_ptr)cprm;

    /* If this first time for this JPEG ?
     */
    if (cinfo->dest == NULL)
    {
        cinfo->dest = (struct jpeg_destination_mgr *)
            (*cinfo->mem->alloc_small) ((j_common_ptr) cinfo,
            JPOOL_PERMANENT, SIZEOF(osaJpegDstManager));
    }

    dest = (osaJpegDstPtr) cinfo->dest;
    dest->pub.init_destination = osal_jpeg_init_destination;
    dest->pub.empty_output_buffer = osal_jpeg_empty_output_buffer;
    dest->pub.term_destination = osal_jpeg_term_destination;
    // dest->bbuf = bbuf;

    err = cinfo->err;
    if (err != NULL)
    {
        err->output_message = osal_jpeg_dst_output_message;
    }
}
