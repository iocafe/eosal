# RaspiCam Documentation

The full documentation for the camera applications is now hosted in the Raspberry Pi documentation area.

[Camera documentation](https://www.raspberrypi.org/documentation/raspbian/applications/camera.md)



