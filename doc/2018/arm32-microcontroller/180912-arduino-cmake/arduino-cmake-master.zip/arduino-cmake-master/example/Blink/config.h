#ifndef CONFIG_H
#define CONFIG_H
class Test1 {
};
#endif
